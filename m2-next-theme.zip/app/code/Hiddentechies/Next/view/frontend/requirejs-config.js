var config = {
    map: {
        '*': {
            nextowlcarousel: 'Hiddentechies_Next/js/owl.carousel',
        }
    }
};